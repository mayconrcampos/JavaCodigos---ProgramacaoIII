package MapaHotel;

public class Principal {
    
    public static void main(String[] args) {
        
        Menu.Principal(); 

    }
}
